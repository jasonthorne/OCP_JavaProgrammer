package com.android;

public class Dog {
	
	String name;
	
	Dog(){
		name="spot";
	}

	@Override
	public String toString() {
		return "Dog [name=" + name + "]";
	}

	
}
