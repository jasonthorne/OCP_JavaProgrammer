package com.android;

public class Janitor {
	
	public String toString() {
		return "this school has a janitor";
	}

}
