package com.android;

public class Ostrich {

}
