package com.android;

public class Main {

	public static void main(String[] args) {
	//	Examples.ex1();
	//	Examples.ex2();
	//	Examples.ex3();
	//	Examples.ex4();
	//	Examples.ex5();
	//	Examples.ex6();
	//	Examples.ex7();
	//	Examples.muck();
	//	Examples.ex10();
	//	Examples.ex11();
	//	Examples.ex12();
	//	Examples.ex13();
	//	Examples.ex14();
	//	Examples.ex15();
	//	Examples.ex16();
		Examples.ex17();
	

	}

}
