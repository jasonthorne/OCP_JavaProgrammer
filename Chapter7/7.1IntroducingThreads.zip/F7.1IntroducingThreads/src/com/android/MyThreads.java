package com.android;

public class MyThreads extends Thread{
	
	@Override
	public void run() {
		System.out.println("using extends thread to create a thread");
	}

}
