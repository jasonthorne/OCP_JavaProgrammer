package com.android;

public class Dog {
	int dogCount=0;

}
