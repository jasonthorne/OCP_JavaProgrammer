package com.android;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	Examples.ex1();
	//	Examples.ex2();
	//	Examples.ex3();
	//	Examples.ex4();
	//	Examples.ex5();
	//	Examples.ex6();
	//	Examples.ex7();
	//	Examples.ex8();
	//	Examples.ex9();
	//	Examples.ex10();
	//	Examples.ex11();
		Examples.ex12();
	}

}
