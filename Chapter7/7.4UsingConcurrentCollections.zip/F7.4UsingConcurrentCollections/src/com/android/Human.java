package com.android;

public class Human {

}
